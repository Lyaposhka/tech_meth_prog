#include "Server.hpp"

#include <cctype>
#include <algorithm>

Server::Server() noexcept : tcp_server(new QTcpServer(this))
{
    connect(this->tcp_server, &QTcpServer::newConnection,
            this, &Server::accept_connection);
    this->tcp_server->listen(QHostAddress::LocalHost, 4598);

    qDebug("Server listening on %s:%u",
           this->tcp_server->serverAddress()
             .toString()
             .toLocal8Bit()
             .constData(),
           this->tcp_server->serverPort());
}

void Server::accept_connection()
{
    QTcpSocket *sock = this->tcp_server->nextPendingConnection();
    qDebug("Accepted connection: %s:%u",
           sock->peerAddress()
             .toString()
             .toLocal8Bit()
             .constData(),
           sock->peerPort());

    if (sock == nullptr)
        return;

    sock->connect(sock, &QTcpSocket::readyRead, this, &Server::process_request);
    sock->connect(sock, &QTcpSocket::disconnected,
                  this, &Server::drop_connection);

    sock->write("Welcome to game!\n");
    if (this->sockets.size() >= 4) {
        sock->write("Server full. Try reconnecting later.\n");
        return;
    }
    this->sockets.push_back(sock);
    if (this->sockets.size() > 1)
        sock->write(QString("%1 more players are connected.\n")
                    .arg(this->sockets.size())
                    .toLocal8Bit()
                    .constData());
    if (this->sockets.size() >= 4)
        for (QTcpSocket *e : this->sockets)
            e->write("Game is starting! Write 5 letters.\n");
}

void Server::process_request()
{
    QTcpSocket *sock = qobject_cast<QTcpSocket*>(sender());

    const QByteArray line = sock->readLine().trimmed();
    if (line.isEmpty()) {
        return;
    }

    if (this->letters.size() == 20) {
        for (const char c : line) {
            if (!this->letters.contains(c)) {
                return;
            }
        }
        for (QTcpSocket *s : this->sockets) {
            if (sock != s) {
                s->write(QString("%1\n")
                         .arg(line)
                         .toLocal8Bit()
                         .constData());
            }
        }
        return;
    }

    if (line.size() < 5) {
        sock->write("Write 5 letters withour spaces or other symbols.\n");
        return;
    }

    for (const char c : line) {
        if (std::isalpha(c)) {
            this->letters.push_back(c);
        }
    }

    if (this->letters.size() == 20) {
        for (QTcpSocket *sock : this->sockets) {
            sock->write(QString("Make up words from %1\n")
                        .arg(this->letters)
                        .toLocal8Bit()
                        .constData());
        }
    }
}

void Server::drop_connection()
{
    QTcpSocket *sock = qobject_cast<QTcpSocket*>(sender());

    qDebug("Dropped connection: %s:%u",
           sock->peerAddress()
             .toString()
             .toLocal8Bit()
             .constData(),
           sock->peerPort());



    auto it = std::find(this->sockets.begin(), this->sockets.end(), sock);
    this->sockets.erase(it);
    sock->close();

    if (this->sockets.size() == 3) {
        for (QTcpSocket *s : this->sockets) {
            s->write("Player disconnected! Bye...\n");
            s->close();
        }
        this->sockets.clear();
        this->letters.clear();
    }
}
