#pragma once

#include <vector>

#include <QObject>
#include <QTcpSocket>
#include <QTcpServer>

class Server : public QObject {
    Q_OBJECT

private:
    QTcpServer * const tcp_server;
    std::vector<QTcpSocket*> sockets;
    QString letters;

private slots:
    void accept_connection();
    void process_request();
    void drop_connection();

public:
    Server() noexcept;
};
