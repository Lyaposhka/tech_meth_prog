#include <QCoreApplication>
#include <iostream>

#include "Server.hpp"

int main(int argc, char *argv[])
{
    const char *player_name = "Gamer";
    if (argc > 1) {
        player_name = argv[1];
    }
    
    std::cout << "Hello," << player_name << std::endl;

    QCoreApplication a(argc, argv);

    const auto s = Server();

    a.exec();
    return 0;
}
