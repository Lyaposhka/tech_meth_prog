#include <QCoreApplication>
#include "server.hpp"

int main(int argc, char *argv[]) {
    QCoreApplication app(argc, argv);
    Server server;
    if (!server.startServer(2951)) {
        qCritical() << "Failed to start server";
        return 1;
    }
    return app.exec();
}
