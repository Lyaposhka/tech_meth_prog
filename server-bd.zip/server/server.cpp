#include "server.hpp"
#include <QDataStream>
#include <QJsonDocument>
#include <QJsonObject>

Server::Server(QObject *parent) : QTcpServer(parent) {}

bool Server::startServer(quint16 port) {
    return listen(QHostAddress::Any, port);
}

void Server::incomingConnection(qintptr socketDescriptor) {
    QTcpSocket *clientSocket = new QTcpSocket(this);
    if (clientSocket->setSocketDescriptor(socketDescriptor)) {
        connect(clientSocket, &QTcpSocket::readyRead, this, &Server::onReadyRead);
        connect(clientSocket, &QTcpSocket::disconnected, this, &Server::onClientDisconnected);
        clients[clientSocket] = QByteArray();
    } else {
        delete clientSocket;
    }
}

void Server::onReadyRead() {
    QTcpSocket *clientSocket = qobject_cast<QTcpSocket*>(sender());
    if (!clientSocket) return;

    QByteArray request = clientSocket->readAll();
    QJsonDocument doc = QJsonDocument::fromJson(request);
    QJsonObject obj = doc.object();

    QString type = obj["type"].toString();
    QString username = obj["username"].toString();
    QString password = obj["password"].toString();
    QJsonObject response;

    if (type == "register") {
        bool success = userManager.registerUser(username, password);
        response["type"] = "register";
        response["status"] = success ? "success" : "failure";
    } else if (type == "login") {
        bool success = userManager.authenticateUser(username, password);
        response["type"] = "login";
        response["status"] = success ? "success" : "failure";
    }

    clientSocket->write(QJsonDocument(response).toJson());
}

void Server::onClientDisconnected() {
    QTcpSocket *clientSocket = qobject_cast<QTcpSocket*>(sender());
    if (clientSocket) {
        clients.remove(clientSocket);
        clientSocket->deleteLater();
    }
}
