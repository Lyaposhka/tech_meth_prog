#pragma once

#include <QString>

class UserManager {
public:
    bool registerUser(const QString &username, const QString &password);
    bool authenticateUser(const QString &username, const QString &password);

private:
    QString hashPassword(const QString &password);
};
