#pragma once

#include <QSqlDatabase>
#include <QMutex>

class Database {
public:
    static Database& instance();
    QSqlDatabase getDatabase();

private:
    Database();
    ~Database();
    QSqlDatabase db;
};
