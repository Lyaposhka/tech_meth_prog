#include "database.hpp"
#include <QSqlError>
#include <QSqlQuery>
#include <QDebug>

Database::Database() {
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("users.db");

    if (!db.open()) {
        qCritical() << "Failed to open database:" << db.lastError().text();
    }

    QSqlQuery query(db);
    query.exec("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT)");
}

Database::~Database() {
    db.close();
}

Database& Database::instance() {
    static Database instance;
    return instance;
}

QSqlDatabase Database::getDatabase() {
    return db;
}
