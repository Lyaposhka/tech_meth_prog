#include "usermanager.hpp"
#include "database.hpp"
#include <QSqlQuery>
#include <QSqlError>
#include <QCryptographicHash>
#include <QDebug>

bool UserManager::registerUser(const QString &username, const QString &password) {
    QSqlDatabase db = Database::instance().getDatabase();
    QSqlQuery query(db);

    QString hashedPassword = hashPassword(password);
    query.prepare("INSERT INTO users (username, password) VALUES (:username, :password)");
    query.bindValue(":username", username);
    query.bindValue(":password", hashedPassword);

    bool success = query.exec();

    if (!success) {
        qDebug() << "Registration failed:" << query.lastError().text();
    }

    return success;
}

bool UserManager::authenticateUser(const QString &username, const QString &password) {
    QSqlDatabase db = Database::instance().getDatabase();
    QSqlQuery query(db);

    QString hashedPassword = hashPassword(password);
    query.prepare("SELECT password FROM users WHERE username = :username");
    query.bindValue(":username", username);
    query.exec();

    if (query.next()) {
        QString storedHashedPassword = query.value(0).toString();
        db.close();
        return storedHashedPassword == hashedPassword;
    }

    db.close();
    return false;
}

QString UserManager::hashPassword(const QString &password) {
    return QString(QCryptographicHash::hash(password.toUtf8(), QCryptographicHash::Sha256).toHex());
}
