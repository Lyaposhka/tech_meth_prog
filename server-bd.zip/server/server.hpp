#pragma once

#include <QTcpServer>
#include <QTcpSocket>
#include "usermanager.hpp"

class Server : public QTcpServer {
    Q_OBJECT

public:
    Server(QObject *parent = nullptr);
    bool startServer(quint16 port);

protected:
    void incomingConnection(qintptr socketDescriptor) override;

private slots:
    void onReadyRead();
    void onClientDisconnected();

private:
    QMap<QTcpSocket*, QByteArray> clients;
    UserManager userManager;
};
