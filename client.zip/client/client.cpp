#include "client.hpp"
#include <QJsonDocument>
#include <QJsonObject>

Client::Client(QObject *parent) : QObject(parent) {
    connect(&socket, &QTcpSocket::readyRead, this, &Client::onReadyRead);
    socket.connectToHost("127.0.0.1", 1234);
}

void Client::sendRequest(const QString &type, const QString &username, const QString &password) {
    if (socket.state() == QTcpSocket::ConnectedState) {
        QJsonObject json;
        json["type"] = type;
        json["username"] = username;
        json["password"] = password;
        QJsonDocument doc(json);
        socket.write(doc.toJson());
    }
}

void Client::onReadyRead() {
    QByteArray responseData = socket.readAll();
    QJsonDocument doc = QJsonDocument::fromJson(responseData);
    QJsonObject obj = doc.object();

    QString type = obj["type"].toString();
    QString status = obj["status"].toString();
    emit serverResponse(type, status);
}
