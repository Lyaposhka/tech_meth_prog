#pragma once

#include <QMainWindow>
#include <QLabel>
#include <QVBoxLayout>

class MainWindow {
public:
    QLabel *welcomeLabel;
    QVBoxLayout *verticalLayout;

    void setupUi(QMainWindow *MainWindow) {
        MainWindow->resize(400, 300);
        QWidget *centralWidget = new QWidget(MainWindow);

        verticalLayout = new QVBoxLayout(centralWidget);

        welcomeLabel = new QLabel("Welcome to the Application!", centralWidget);
        welcomeLabel->setAlignment(Qt::AlignCenter);
        verticalLayout->addWidget(welcomeLabel);

        MainWindow->setCentralWidget(centralWidget);
    }
};
