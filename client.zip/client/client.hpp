#pragma once

#include <QTcpSocket>
#include <QObject>

class Client : public QObject {
    Q_OBJECT

public:
    Client(QObject *parent = nullptr);
    void sendRequest(const QString &type, const QString &username, const QString &password);

signals:
    void serverResponse(const QString &type, const QString &status);

private slots:
    void onReadyRead();

private:
    QTcpSocket socket;
};
