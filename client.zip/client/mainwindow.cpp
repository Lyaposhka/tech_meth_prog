#include "mainwindow.hpp"
#include "ui_mainwindow.hpp"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow) {
    ui->setupUi(this);
    // Add any additional setup for the main window here.
}

MainWindow::~MainWindow() {
    delete ui;
}
