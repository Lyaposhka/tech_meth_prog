#pragma once

#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include <QVBoxLayout>
#include "client.hpp"

class Ui_LoginWindow {
public:
    QLineEdit *usernameEdit;
    QLineEdit *passwordEdit;
    QPushButton *loginButton;
    QPushButton *registerButton;
    QLabel *labelUsername;
    QLabel *labelPassword;
    QVBoxLayout *verticalLayout;

    void setupUi(QWidget *LoginWindow) {
        LoginWindow->resize(300, 200);
        verticalLayout = new QVBoxLayout(LoginWindow);

        labelUsername = new QLabel("Username:", LoginWindow);
        verticalLayout->addWidget(labelUsername);

        usernameEdit = new QLineEdit(LoginWindow);
        usernameEdit->setPlaceholderText("Enter username");
        verticalLayout->addWidget(usernameEdit);

        labelPassword = new QLabel("Password:", LoginWindow);
        verticalLayout->addWidget(labelPassword);

        passwordEdit = new QLineEdit(LoginWindow);
        passwordEdit->setPlaceholderText("Enter password");
        passwordEdit->setEchoMode(QLineEdit::Password);
        verticalLayout->addWidget(passwordEdit);

        loginButton = new QPushButton("Login", LoginWindow);
        verticalLayout->addWidget(loginButton);

        registerButton = new QPushButton("Register", LoginWindow);
        verticalLayout->addWidget(registerButton);
    }
};
