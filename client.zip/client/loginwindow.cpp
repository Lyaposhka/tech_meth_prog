#include "loginwindow.hpp"
#include "ui_loginwindow.hpp"
#include "mainwindow.hpp"
#include <QMessageBox>

LoginWindow::LoginWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LoginWindow) {
    ui->setupUi(this);
    connect(ui->loginButton, &QPushButton::clicked, this, &LoginWindow::onLoginClicked);
    connect(ui->registerButton, &QPushButton::clicked, this, &LoginWindow::onRegisterClicked);
    connect(&client, &Client::serverResponse, this, &LoginWindow::onServerResponse);
}

LoginWindow::~LoginWindow() {
    delete ui;
}

void LoginWindow::onLoginClicked() {
    QString username = ui->usernameEdit->text();
    QString password = ui->passwordEdit->text();
    client.sendRequest("login", username, password);
}

void LoginWindow::onRegisterClicked() {
    QString username = ui->usernameEdit->text();
    QString password = ui->passwordEdit->text();
    client.sendRequest("register", username, password);
}

void LoginWindow::onServerResponse(const QString &type, const QString &status) {
    if (type == "register") {
        if (status == "success") {
            QMessageBox::information(this, "Registration", "Registration successful!");
        } else {
            QMessageBox::warning(this, "Registration", "Registration failed.");
        }
    } else if (type == "login") {
        if (status == "success") {
            QMessageBox::information(this, "Login", "Login successful!");
            MainWindow *mainWindow = new MainWindow();
            mainWindow->show();
            this->close();
        } else {
            QMessageBox::warning(this, "Login", "Login failed.");
        }
    }
}
