#pragma once

#include <QWidget>
#include "client.hpp"

QT_BEGIN_NAMESPACE
namespace Ui { class LoginWindow; }
QT_END_NAMESPACE

class LoginWindow : public QWidget {
    Q_OBJECT

public:
    LoginWindow(QWidget *parent = nullptr);
    ~LoginWindow();

private slots:
    void onLoginClicked();
    void onRegisterClicked();
    void onServerResponse(const QString &type, const QString &status);

private:
    Ui::LoginWindow *ui;
    Client client;
};
