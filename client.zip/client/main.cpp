#include <QApplication>
#include "loginwindow.hpp"

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    LoginWindow loginWindow;
    loginWindow.show();
    return app.exec();
}
